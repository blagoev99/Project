var questions = [{
  "question" : "In HTML, tag used to specify background color is?",
  "option1" : "<bg> yellow </bg>",
  "option2" : "<body bg='black'>",
  "option3" : "<body background='black'>",
  "option4" : "<body style='background-color:black'>",
  "answer" : "4"
},{
  "question" : "What does HTML stand for?",
  "option1" : "Hypertext and links markup language.",
  "option2" : "Hypertext Markup Language.",
  "option3" : "Hypertext Machine language.",
  "option4" : "Hightext machine language.",
  "answer" : "2"
},{
  "question" : "Which of the following characters indicate closing of a tag?",
  "option1" : ".",
  "option2" : ";",
  "option3" : "/",
  "option4" : "::",
  "answer" : "3"
},{
  "question" : "How is document type initialized in HTML5?",
  "option1" : "</DOCTYPE HTML>",
  "option2" : "</DOCTYPE>",
  "option3" : "</DOCTYPE html>",
  "option4" : "<!DOCTYPE HTML>",
  "answer" : "4"
},{
  "question" : "Which of the following JavaScript cannot do?",
  "option1" : "JavaScript can react to events",
  "option2" : "JavaScript can be use to validate data",
  "option3" : "JavaScript can manipulate HTML elements",
  "option4" : "All of the above",
  "answer" : "4"
},{
  "question" : "What is the correct HTML for making a drop-down list?",
  "option1" : "<input type='list' />",
  "option2" : "<select>",
  "option3" : "You cannot make a drop-down in HTML",
  "option4" : "<input type='dropdown' />",
  "answer" : "2"
}

];
