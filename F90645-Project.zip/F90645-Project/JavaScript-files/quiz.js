var currentQuestion = 0;
var score = 0;
var totalQuestitons = questions.length;

var container = document.getElementById('quizContainer');
var questionEl = document.getElementById('question');
var opt1 = document.getElementById('opt1');
var opt2 = document.getElementById('opt2');
var opt3 = document.getElementById('opt3');
var opt4 = document.getElementById('opt4');
var nextButton = document.getElementById('nextButton');
var resultCont = document.getElementById('result');

function loadQuestion(questionIndex){
  var q = questions[questionIndex];
  questionEl.textContent = (questionIndex + 1) + '. ' + q.question;
  opt1.textContent = q.option1;
  opt2.textContent = q.option2;
  opt3.textContent = q.option3;
  opt4.textContent = q.option4;
};

function loadNextQuestion(){
  var selectedOption = document.querySelector('input[type=radio]:checked')

  var givenAnswer = selectedOption.value;
  if(questions[currentQuestion].answer == givenAnswer){
    score += 10;
  }
  selectedOption.checked = false;
  currentQuestion++;
  if(currentQuestion == totalQuestitons - 1){
    nextButton.textContent = 'Finish';
  }
  if(currentQuestion == totalQuestitons){
    container.style.display = 'none';
    nextButton.style.display = 'none';
    resultCont.style.display = 'block';
    resultCont.textContent = 'Your score is: ' + score;
    document.body.style.backgroundImage = "url('Images/bckimg.png.png')";
    return;
  }
  loadQuestion(currentQuestion);
}

loadQuestion(currentQuestion);
